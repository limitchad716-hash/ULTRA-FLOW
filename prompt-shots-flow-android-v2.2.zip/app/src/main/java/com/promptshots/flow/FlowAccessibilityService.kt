package com.promptshots.flow

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

enum class PromptKind { IMAGE, VIDEO }

/** What the service could read from the Flow screen: image or video mode, and the model chip text. */
data class FlowScreen(val kind: PromptKind?, val model: String?)

class FlowAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: FlowAccessibilityService? = null
        // Whole-word matches only, so "truncate" or "running..." never counts as "run".
        private val STRONG = Regex("\\b(generate|arrow_forward|send|submit)\\b")
        private val WEAK = Regex("\\brun\\b")
        // Real buttons have short labels; long text blocks are never the Generate button.
        private const val MAX_LABEL = 40
        private val VIDEO_HINT = Regex("\\b(veo|text to video|frames to video|ingredients to video)\\b")
        private val IMAGE_HINT = Regex("\\b(nano banana|imagen)\\b")
        private val WORD_VIDEO = Regex("^\\s*videos?\\s*$")
        private val WORD_IMAGE = Regex("^\\s*(images?|photos?)\\s*$")
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun roots(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        for (w in windows) {
            if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
            val r = w.root ?: continue
            if (r.packageName?.toString() != packageName) out.add(r)
        }
        if (out.isEmpty()) rootInActiveWindow?.let { if (it.packageName?.toString() != packageName) out.add(it) }
        return out
    }

    private fun walk(root: AccessibilityNodeInfo, visit: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        while (q.isNotEmpty()) {
            val n = q.removeFirst()
            if (visit(n)) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return null
    }

    private fun findField(): AccessibilityNodeInfo? {
        val rs = roots()
        for (r in rs) walk(r) { it.isEditable && it.isFocused }?.let { return it }
        for (r in rs) walk(r) { it.isEditable && it.isVisibleToUser }?.let { return it }
        return null
    }

    private fun label(n: AccessibilityNodeInfo) =
        ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()

    private fun findButton(): AccessibilityNodeInfo? {
        val rs = roots()
        for (re in listOf(STRONG, WEAK)) {
            for (r in rs) walk(r) {
                // Never treat the prompt box itself (its hint says "What do you want to create?") as a button.
                if (!it.isVisibleToUser || !it.isEnabled || it.isEditable) return@walk false
                val l = label(it).trim()
                l.isNotEmpty() && l.length <= MAX_LABEL && re.containsMatchIn(l)
            }?.let { return it }
        }
        return null
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    /**
     * Reads the visible Flow screen and guesses whether it is in image or video mode.
     * Model chips (Nano Banana / Imagen vs Veo) are the strongest signal; plain "Image"/"Video"
     * labels are only used when exactly one of them is visible.
     */
    fun detectScreen(): FlowScreen {
        var video: String? = null
        var image: String? = null
        var wordVideo = false
        var wordImage = false
        for (r in roots()) walk(r) { n ->
            if (n.isVisibleToUser && !n.isEditable) {
                val raw = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).trim()
                val l = raw.lowercase()
                if (raw.isNotEmpty() && l.length <= MAX_LABEL) {
                    if (video == null && VIDEO_HINT.containsMatchIn(l)) video = raw
                    else if (image == null && IMAGE_HINT.containsMatchIn(l)) image = raw
                    if (WORD_VIDEO.containsMatchIn(l)) wordVideo = true
                    if (WORD_IMAGE.containsMatchIn(l)) wordImage = true
                }
            }
            false
        }
        return when {
            video != null -> FlowScreen(PromptKind.VIDEO, video)
            image != null -> FlowScreen(PromptKind.IMAGE, image)
            wordVideo && !wordImage -> FlowScreen(PromptKind.VIDEO, null)
            wordImage && !wordVideo -> FlowScreen(PromptKind.IMAGE, null)
            else -> FlowScreen(null, null)
        }
    }

    /**
     * Types the prompt into Flow's prompt box, then taps Generate.
     * [done] gets (success, message). success is true only when Generate was really tapped.
     */
    fun pasteAndRun(text: String, done: (Boolean, String) -> Unit) {
        val field = findField()
        if (field == null) { done(false, "Can't find the prompt box. Open Google Flow first."); return }
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            done(false, "Couldn't type into the prompt box."); return
        }
        // Give the page a moment to enable the Generate button; retry a few times.
        val h = Handler(Looper.getMainLooper())
        var tries = 0
        val attempt = object : Runnable {
            override fun run() {
                val b = findButton()
                when {
                    b != null && click(b) -> done(true, "Sent")
                    ++tries < 4 -> h.postDelayed(this, 500)
                    b == null -> done(false, "Pasted, but can't find Generate. Tap it yourself.")
                    else -> done(false, "Pasted, but Generate didn't respond. Tap it yourself.")
                }
            }
        }
        h.postDelayed(attempt, 700)
    }
}
