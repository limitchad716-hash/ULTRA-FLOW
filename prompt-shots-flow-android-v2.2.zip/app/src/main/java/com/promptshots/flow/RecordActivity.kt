package com.promptshots.flow

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast

/**
 * Invisible activity whose only job is to show Android's "start recording?" permission dialog.
 * On OK it hands the permission to RecordService and closes.
 */
class RecordActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res == RESULT_OK && data != null) {
            val i = Intent(this, RecordService::class.java)
                .putExtra("code", res)
                .putExtra("data", data)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } else {
            Toast.makeText(this, "Kinansela ang screen record", Toast.LENGTH_SHORT).show()
            RecordService.onChange?.invoke()
        }
        finish()
    }
}
