package com.promptshots.flow

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.view.animation.LinearInterpolator

/**
 * Rounded panel background with a rainbow border that keeps rotating.
 * Only the shader matrix changes each frame, so it stays smooth (follows the screen's refresh rate).
 */
class RainbowBorder(
    private val radius: Float,
    private val stroke: Float,
    fillColor: Int
) : Drawable() {
    private val rainbow = intArrayOf(
        0xFFFF3B3B.toInt(), 0xFFFF9800.toInt(), 0xFFFFEB3B.toInt(), 0xFF3DDC84.toInt(),
        0xFF29C5F6.toInt(), 0xFF5C6BFF.toInt(), 0xFFD84BFF.toInt(), 0xFFFF3B3B.toInt()
    )
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = fillColor }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke }
    private val rect = RectF()
    private val matrix = Matrix()
    private var shader: SweepGradient? = null
    private var angle = 0f
    private var anim: ValueAnimator? = null

    fun start() {
        if (anim != null) return
        anim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 4000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { angle = it.animatedValue as Float; invalidateSelf() }
            start()
        }
    }

    fun stop() {
        anim?.cancel()
        anim = null
    }

    override fun onBoundsChange(b: Rect) {
        shader = SweepGradient(b.exactCenterX(), b.exactCenterY(), rainbow, null)
        ring.shader = shader
    }

    override fun draw(canvas: Canvas) {
        rect.set(bounds)
        canvas.drawRoundRect(rect, radius, radius, fill)
        shader?.let {
            matrix.setRotate(angle, bounds.exactCenterX(), bounds.exactCenterY())
            it.setLocalMatrix(matrix)
            ring.shader = it
        }
        val half = stroke / 2f
        rect.inset(half, half)
        canvas.drawRoundRect(rect, radius - half, radius - half, ring)
    }

    override fun setAlpha(alpha: Int) { fill.alpha = alpha; ring.alpha = alpha; invalidateSelf() }
    override fun setColorFilter(cf: ColorFilter?) { fill.colorFilter = cf; ring.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}
