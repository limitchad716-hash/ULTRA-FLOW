package com.promptshots.flow

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FloatingService : Service() {
    companion object {
        /** True while the bubble exists; MainActivity uses it to label the Float button. */
        @Volatile var alive = false
        private const val ACTION_STOP = "com.promptshots.flow.STOP"
        private const val BUBBLE_DP = 76 // view size, includes room for the glow
        private val DELAY_PRESETS = intArrayOf(10, 20, 30, 45, 60, 90, 120, 180, 300)

        /** One prompt per line; or, if there are blank lines, one prompt per paragraph. */
        fun parsePrompts(text: String): List<String> {
            val t = text.replace("\r\n", "\n")
            val parts = if (t.contains("\n\n")) {
                t.split(Regex("\n\\s*\n")).map { block -> block.lines().joinToString(" ") { it.trim() }.trim() }
            } else {
                t.lines().map { it.trim() }
            }
            return parts.filter { it.isNotEmpty() }
        }
    }

    private lateinit var wm: WindowManager
    private val h = Handler(Looper.getMainLooper())
    private var bubble: GlowBubble? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var edit: EditText? = null
    private var info: TextView? = null
    private val poll = Handler(Looper.getMainLooper())
    private var panelBorder: RainbowBorder? = null
    private var shownKind = PromptKind.IMAGE
    private var selected = 0 // 0 = Auto, 1 = Image, 2 = Video
    private val idxByKind = intArrayOf(0, 0)
    private var detected: FlowScreen? = null
    private var modeBadge: TextView? = null
    private val segs = arrayOfNulls<Button>(3)
    private var tipView: TextView? = null
    private var runCircle: TextView? = null
    private var pauseCircle: TextView? = null
    private var recCircle: TextView? = null
    private var helpPinned = false
    private var paused = false
    private var index = 0
    private var running = false
    private var remaining = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        alive = true
        RecordService.onChange = { h.post { if (alive) refresh() } }
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        startAsForeground()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (bubble == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            addBubble()
        }
        // Not sticky: on Android 12+ the system can't restart a foreground service from the background.
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        alive = false
        RecordService.onChange = null
        running = false
        h.removeCallbacksAndMessages(null)
        poll.removeCallbacksAndMessages(null)
        panelBorder?.stop()
        if (::wm.isInitialized) {
            panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        }
        panel = null; bubble = null
        super.onDestroy()
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    @Suppress("DEPRECATION")
    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("flow", "Floating window", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "flow") else Notification.Builder(this)
        val n = b.setContentTitle("FLOW floating window is on")
            .setContentText("Tap to open Prompt Shots")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Close", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ── Bubble ─────────────────────────────────────────────────────────────

    private fun addBubble() {
        val t = GlowBubble(this).apply { glow = Prefs.flag(this@FloatingService, "glow", true) }
        val size = dp(BUBBLE_DP)
        val lp = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0; lp.y = dp(140)
        t.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val dm = resources.displayMetrics
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        if (moved) {
                            lp.x = (sx + dx).coerceIn(0, maxOf(0, dm.widthPixels - size))
                            lp.y = (sy + dy).coerceIn(0, maxOf(0, dm.heightPixels - size))
                            wm.updateViewLayout(v, lp)
                            positionPanel()
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(70).withEndAction {
                            v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        }.start()
                        togglePanel()
                    } else {
                        // Snap to the nearest screen edge so the bubble stays out of the way.
                        lp.x = if (lp.x + size / 2 < dm.widthPixels / 2) 0 else dm.widthPixels - size
                        wm.updateViewLayout(v, lp)
                        positionPanel()
                    }
                }
                return true
            }
        })
        wm.addView(t, lp)
        bubble = t; bubbleLp = lp
    }

    /** Idle: "FLOW". Running: seconds until the next prompt, in green. */
    private fun updateBubble() {
        val b = bubble ?: return
        b.label = when {
            !running -> if (RecordService.recording) "REC" else "FLOW"
            paused -> "II"
            remaining > 0 -> "$remaining"
            else -> "…"
        }
        b.textSp = if (running) 16f else 11f
        b.fill = if (running) Ui.OK else if (RecordService.recording) Ui.BAD else Ui.ACCENT
    }

    // ── Panel ──────────────────────────────────────────────────────────────

    private fun panelWidth() = minOf(dp(320), resources.displayMetrics.widthPixels - dp(16))

    /** Keeps the panel next to the bubble and fully on screen (above it if there's no room below). */
    private fun positionPanel() {
        val p = panel ?: return
        val bl = bubbleLp ?: return
        val lp = p.layoutParams as? WindowManager.LayoutParams ?: return
        val dm = resources.displayMetrics
        lp.x = bl.x.coerceIn(0, maxOf(0, dm.widthPixels - lp.width))
        val below = bl.y + dp(BUBBLE_DP - 6)
        val ph = if (p.height > 0) p.height else dp(430)
        lp.y = if (below + ph > dm.heightPixels - dp(24)) maxOf(0, bl.y - ph - dp(6)) else below
        try { wm.updateViewLayout(p, lp) } catch (_: Exception) {}
    }

    private fun togglePanel() {
        val old = panel
        if (old != null) {
            list() // saves prompts
            val border = panelBorder
            panel = null; edit = null; info = null; tipView = null; runCircle = null; pauseCircle = null; recCircle = null
            modeBadge = null; panelBorder = null
            poll.removeCallbacksAndMessages(null)
            // Shrink + fade out, then remove the window.
            old.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f).setDuration(160)
                .setInterpolator(DecelerateInterpolator())
                .withEndAction {
                    border?.stop()
                    try { wm.removeView(old) } catch (_: Exception) {}
                }.start()
            return
        }
        val p = buildPanel()
        val lp = WindowManager.LayoutParams(
            panelWidth(), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        lp.x = bubbleLp?.x ?: 0; lp.y = (bubbleLp?.y ?: dp(140)) + dp(BUBBLE_DP - 6)
        p.alpha = 0f // hidden until positioned, then it pops in
        wm.addView(p, lp)
        panel = p
        panelBorder?.start()
        refresh()
        p.post {
            positionPanel()
            // Grow out of the bubble: pivot near the bubble, on the side the panel opened.
            val bl = bubbleLp
            val wl = p.layoutParams as? WindowManager.LayoutParams
            if (bl != null && wl != null) {
                p.pivotX = (bl.x + dp(BUBBLE_DP) / 2 - wl.x).toFloat().coerceIn(0f, p.width.toFloat())
                p.pivotY = if (wl.y >= bl.y) 0f else p.height.toFloat()
            }
            p.scaleX = 0.8f; p.scaleY = 0.8f
            p.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(230)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        }
        applyAuto()
        poll.postDelayed(detectTick, 1500)
    }

    private val detectTick = object : Runnable {
        override fun run() {
            if (panel == null) return
            applyAuto()
            poll.postDelayed(this, 1500)
        }
    }

    // ── Circle options ─────────────────────────────────────────────────────

    private fun showTip(text: String) {
        tipView?.let { it.text = text; it.visibility = View.VISIBLE }
        panel?.post { positionPanel() }
    }

    private fun hideTip() {
        if (helpPinned) return
        tipView?.visibility = View.GONE
        panel?.post { positionPanel() }
    }

    private fun paintCircle(t: TextView, bg: Int, fg: Int) {
        t.background = Ui.circleBg(bg)
        t.setTextColor(fg)
    }

    /** Toggle look: accent when on, grey when off. */
    private fun setOn(t: TextView, on: Boolean) =
        if (on) paintCircle(t, Ui.ACCENT, Ui.ON_ACCENT) else paintCircle(t, Ui.SURFACE_HI, Ui.TEXT)

    /**
     * A small round option button. Tap = do it. Hold = show what it does (tip disappears on release).
     */
    private fun circle(glyph: String, tip: () -> String, danger: Boolean = false, onClick: (TextView) -> Unit): TextView {
        val t = TextView(this).apply {
            text = glyph; textSize = 18f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            isClickable = true
        }
        if (danger) paintCircle(t, Ui.BAD_BG, Ui.BAD) else paintCircle(t, Ui.SURFACE_HI, Ui.TEXT)
        t.setOnClickListener { onClick(t) }
        holdTip(t, tip)
        return t
    }

    /** Hold a view to show [tip]; it disappears on release. */
    private fun holdTip(v: View, tip: () -> String) {
        v.setOnLongClickListener { showTip(tip()); true }
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) hideTip()
            false
        }
    }

    // ── Image / Video / Auto ───────────────────────────────────────────────

    private fun kindIcon(k: PromptKind) = if (k == PromptKind.VIDEO) "🎬" else "🖼"
    private fun kindName(k: PromptKind) = if (k == PromptKind.VIDEO) "Video" else "Image"
    private fun hintFor(k: PromptKind) =
        "${kindName(k)} prompts: isa kada linya\n(o paghiwalayin ng blank line)"

    /** Shows the other prompt list in the box; each kind keeps its own prompts and position. */
    private fun switchKind(k: PromptKind) {
        if (k == shownKind) return
        idxByKind[shownKind.ordinal] = index
        shownKind = k
        index = idxByKind[k.ordinal]
        edit?.let { it.hint = hintFor(k); it.setText(Prefs.prompts(this, k)) }
        refresh()
    }

    private fun styleSegs() {
        for (i in 0..2) segs[i]?.let { Ui.style(it, if (selected == i) Ui.Kind.PRIMARY else Ui.Kind.SECONDARY) }
    }

    private fun selectMode(m: Int) {
        if (running) { toast("Itigil muna ang Run all bago magpalit"); return }
        selected = m
        styleSegs()
        when (m) {
            1 -> switchKind(PromptKind.IMAGE)
            2 -> switchKind(PromptKind.VIDEO)
            else -> applyAuto()
        }
        updateBadge()
    }

    /** Reads the Flow screen; in Auto mode, switches to the matching prompt list. */
    private fun applyAuto() {
        val svc = FlowAccessibilityService.instance
        detected = svc?.detectScreen()
        val k = detected?.kind
        if (selected == 0 && k != null && !running) switchKind(k)
        updateBadge()
    }

    private fun updateBadge() {
        val k = detected?.kind
        val model = detected?.model
        modeBadge?.text = when {
            FlowAccessibilityService.instance == null -> "Auto-detect: i-on ang Accessibility sa Setup"
            k == null -> "Hindi pa mabasa ang Flow. Buksan ang Google Flow."
            else -> "Nakita: ${kindIcon(k)} ${kindName(k)}" + (if (model != null) "  ·  $model" else "")
        }
    }

    private fun circleRow(vararg v: View): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        v.forEach {
            val lp = LinearLayout.LayoutParams(dp(46), dp(46))
            lp.setMargins(dp(5), dp(4), dp(5), dp(4))
            r.addView(it, lp)
        }
        return r
    }

    private fun onOff(b: Boolean) = if (b) " (Naka-on)" else " (Naka-off)"
    private fun flag(k: String, def: Boolean) = Prefs.flag(this, k, def)

    private fun buildPanel(): LinearLayout {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            val rb = RainbowBorder(dp(18).toFloat(), dp(2).toFloat(), 0xF2151A24.toInt())
            panelBorder = rb
            background = rb
            elevation = dp(8).toFloat()
        }
        val title = TextView(this).apply {
            text = "FLOW  paste & run"; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.ACCENT); textSize = 14f
        }
        val hide = Ui.button(this, "–", Ui.Kind.SECONDARY) { togglePanel() }.apply {
            setPadding(dp(14), dp(2), dp(14), dp(2)); textSize = 16f
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(hide)

        val e = EditText(this).apply {
            hint = hintFor(shownKind)
            setHintTextColor(Ui.MUTED); setTextColor(Ui.TEXT); textSize = 13f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3; maxLines = 5; gravity = Gravity.TOP
            background = Ui.rounded(Ui.SURFACE, dp(10).toFloat())
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setText(Prefs.prompts(this@FloatingService, shownKind))
        }
        edit = e
        val i = TextView(this).apply { setTextColor(Ui.MUTED); textSize = 12f; setPadding(dp(3), dp(6), dp(3), dp(4)) }
        info = i
        e.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                Prefs.setPrompts(this@FloatingService, s?.toString() ?: "", shownKind)
                refresh()
            }
        })

        // Explanation box: shown while a circle is held (or pinned by the "!" button).
        val tip = TextView(this).apply {
            setTextColor(Ui.TEXT); textSize = 12f
            background = Ui.rounded(Ui.SURFACE, dp(10).toFloat())
            setPadding(dp(10), dp(8), dp(10), dp(8))
            visibility = View.GONE
        }
        tipView = tip
        helpPinned = false

        // Row 1: sending
        val runThis = circle("▶", { "Ipadala ang kasalukuyang prompt lang (i-paste + Generate)." }) { runOne() }
        paintCircle(runThis, Ui.ACCENT, Ui.ON_ACCENT)
        val runAllC = circle("⏩", { "Ipadala lahat ng prompt isa-isa na may paghihintay sa pagitan. Pindutin ulit para huminto." }) {
            if (running) stopAll("Stopped") else runAll()
        }
        runCircle = runAllC
        val pauseC = circle("⏸", { "I-pause o ituloy ang countdown habang tumatakbo ang Run all." }) { togglePause() }
        pauseCircle = pauseC
        val prev = circle("‹", { "Bumalik sa nakaraang prompt." }) { index = maxOf(0, index - 1); refresh() }
        val skip = circle("›", { "Laktawan ang kasalukuyang prompt." }) { index++; refresh() }

        // Row 2: list + timing
        val restart = circle("↺", { "Ibalik sa unang prompt." }) { index = 0; refresh() }
        val paste = circle("📋", { "I-paste ang listahan ng prompts mula sa clipboard." }) { pasteClipboard() }
        val clear = circle("🗑", { "Burahin lahat ng prompts sa kahon." }) { e.setText(""); index = 0; refresh() }
        val wait = circle("⏱", {
            "Oras ng paghihintay sa pagitan ng mga prompt: ${Prefs.delay(this)} s. I-tap para palitan (10, 20, 30, 45, 60, 90, 120, 180, 300)."
        }) {
            val cur = Prefs.delay(this)
            val next = DELAY_PRESETS.firstOrNull { it > cur } ?: DELAY_PRESETS[0]
            Prefs.setDelay(this, next)
            toast("Wait: $next s")
        }
        val loop = circle("🔁", { "Uulit mula sa simula pagkatapos ng huling prompt." + onOff(flag("loop", false)) }) { t ->
            val v = !flag("loop", false); Prefs.setFlag(this, "loop", v); setOn(t, v)
            toast("Loop" + onOff(v))
        }
        setOn(loop, flag("loop", false))

        // Row 3: options
        val jitter = circle("🎲", { "Random na ±20% sa paghihintay para hindi laging pare-pareho ang oras." + onOff(flag("jitter", false)) }) { t ->
            val v = !flag("jitter", false); Prefs.setFlag(this, "jitter", v); setOn(t, v)
            toast("Random wait" + onOff(v))
        }
        setOn(jitter, flag("jitter", false))
        val glowC = circle("🌈", { "Rainbow glow ng bubble. I-off para makatipid ng battery." + onOff(flag("glow", true)) }) { t ->
            val v = !flag("glow", true); Prefs.setFlag(this, "glow", v); setOn(t, v)
            bubble?.glow = v
            toast("Glow" + onOff(v))
        }
        setOn(glowC, flag("glow", true))
        val autoHide = circle("🙈", { "Kusang itatago ang panel kapag sinimulan ang Run all para hindi matakpan ang Flow." + onOff(flag("autohide", true)) }) { t ->
            val v = !flag("autohide", true); Prefs.setFlag(this, "autohide", v); setOn(t, v)
            toast("Auto-hide" + onOff(v))
        }
        setOn(autoHide, flag("autohide", true))
        val help = circle("!", { "Pindutin para ipakita ang gabay. Pindutin ulit para itago." }) { _ ->
            helpPinned = !helpPinned
            if (helpPinned) showTip(
                "Hawakan ang kahit anong bilog para makita kung para saan ito.\n\n" +
                "1. Buksan ang Google Flow\n2. I-paste o i-type ang prompts dito\n3. Pindutin ang ▶ (isa) o ⏩ (lahat)\n\n" +
                "Naka-orange = naka-on ang option."
            ) else { tipView?.visibility = View.GONE; panel?.post { positionPanel() } }
        }
        val close = circle("✕", { "Isara ang FLOW at alisin ang bubble." }, danger = true) { stopSelf() }

        // Auto / Image / Video selector + what the app currently sees in Flow
        val segAuto = Ui.button(this, "✨ Auto", Ui.Kind.SECONDARY) { selectMode(0) }
        val segImg = Ui.button(this, "🖼 Image", Ui.Kind.SECONDARY) { selectMode(1) }
        val segVid = Ui.button(this, "🎬 Video", Ui.Kind.SECONDARY) { selectMode(2) }
        segs[0] = segAuto; segs[1] = segImg; segs[2] = segVid
        holdTip(segAuto) { "Awtomatikong binabasa ang Flow screen at pinipili ang Image o Video prompts ayon sa nakikita." }
        holdTip(segImg) { "Listahan ng prompts para sa larawan. Hiwalay ito sa Video." }
        holdTip(segVid) { "Listahan ng prompts para sa video. Hiwalay ito sa Image." }
        styleSegs()
        val badge = TextView(this).apply { setTextColor(Ui.MUTED); textSize = 11f; setPadding(dp(3), dp(2), dp(3), dp(2)) }
        modeBadge = badge
        updateBadge()

        p.addView(head)
        p.addView(Ui.row(this, segAuto, segImg, segVid))
        p.addView(badge)
        p.addView(e, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(6) })
        p.addView(i)
        p.addView(tip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { bottomMargin = dp(4) })
        p.addView(circleRow(runThis, runAllC, pauseC, prev, skip))
        p.addView(circleRow(restart, paste, clear, wait, loop))
        val rec = circle("⏺", { "I-record ang screen (60 fps, video lang). Lalabas ang pulang ■ box para huminto at ⏸ para mag-pause. Auto-save sa Gallery." }) { toggleRecord() }
        recCircle = rec
        paintCircle(rec, Ui.SURFACE_HI, Ui.BAD)
        p.addView(circleRow(jitter, glowC, autoHide, help, close))
        val touch = circle("👆", { "Ipakita ang bilog kung saan ka pumipindot sa video ng screen record." + onOff(flag("showtouch", false)) }) { t ->
            val v = !flag("showtouch", false)
            Prefs.setFlag(this, "showtouch", v); setOn(t, v)
            toast("Show touch" + onOff(v))
            if (v && checkSelfPermission(android.Manifest.permission.WRITE_SECURE_SETTINGS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Walang permission: i-on mo muna ang 'Show taps' sa Developer options (o tingnan ang README para sa auto).", Toast.LENGTH_LONG).show()
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
            }
        }
        setOn(touch, flag("showtouch", false))
        p.addView(circleRow(rec, touch))
        return p
    }

    private fun list(): List<String> =
        parsePrompts(edit?.text?.toString() ?: Prefs.prompts(this, shownKind))

    private fun refresh() {
        val l = list()
        if (index >= l.size) index = 0
        info?.text = when {
            l.isEmpty() -> "No prompts yet"
            running && paused -> "Paused at ${index + 1} / ${l.size}"
            running && remaining > 0 -> "Running ${index + 1} / ${l.size}  ·  next in ${remaining}s"
            running -> "Running ${index + 1} / ${l.size}…"
            else -> "${kindIcon(shownKind)} Next: ${index + 1} / ${l.size}  ·  " + l[index].take(34) + if (l[index].length > 34) "…" else ""
        }
        runCircle?.let {
            it.text = if (running) "■" else "⏩"
            if (running) paintCircle(it, Ui.BAD_BG, Ui.BAD) else paintCircle(it, Ui.SURFACE_HI, Ui.TEXT)
        }
        recCircle?.let {
            it.text = if (RecordService.recording) "⏹" else "⏺"
            if (RecordService.recording) paintCircle(it, Ui.BAD, Ui.TEXT) else paintCircle(it, Ui.SURFACE_HI, Ui.BAD)
        }
        pauseCircle?.let {
            it.text = if (paused) "▶" else "⏸"
            setOn(it, paused)
        }
        updateBubble()
    }

    private fun toggleRecord() {
        if (RecordService.recording) {
            startService(Intent(this, RecordService::class.java).setAction(RecordService.ACTION_STOP))
            return
        }
        // Keep the panel out of the video; Android then shows its own "start recording?" dialog.
        if (panel != null) togglePanel()
        startActivity(Intent(this, RecordActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun togglePause() {
        if (!running) { toast("Walang tumatakbo"); return }
        paused = !paused
        refresh()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun pasteClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrBlank()) { toast("Clipboard is empty. Copy your prompts in Prompt Shots first."); return }
        edit?.setText(t); index = 0; refresh()
    }

    // ── Running ────────────────────────────────────────────────────────────

    private fun runOne() {
        if (running) { toast("Run all is active. Stop it first."); return }
        if (selected == 0) applyAuto()
        val l = list()
        if (l.isEmpty()) { toast("Add prompts first"); return }
        if (index >= l.size) index = 0
        val svc = FlowAccessibilityService.instance
        if (svc == null) { toast("Turn on Accessibility in Prompt Shots > Setup"); return }
        svc.pasteAndRun(l[index]) { ok, msg ->
            toast(msg)
            if (ok) { index++; refresh() } // a failed prompt stays selected so you can retry it
        }
    }

    private fun runAll() {
        if (running) return
        if (selected == 0) applyAuto()
        if (list().isEmpty()) { toast("Add prompts first"); return }
        if (FlowAccessibilityService.instance == null) { toast("Turn on Accessibility in Prompt Shots > Setup"); return }
        running = true
        remaining = 0
        refresh()
        // Get the panel out of the way so it doesn't cover Flow while it works.
        if (panel != null && flag("autohide", true)) togglePanel()
        step()
    }

    private fun stopAll(msg: String? = null) {
        running = false
        paused = false
        remaining = 0
        h.removeCallbacksAndMessages(null)
        refresh()
        if (msg != null) toast(msg)
    }

    /** Ends Run all and tells the user with a notification only (no toast). */
    private fun finish(title: String, text: String) {
        stopAll()
        Notifier.done(this, title, text)
    }

    /** Sends the current prompt. On success, counts down the wait, then goes again. */
    private fun step() {
        if (!running) return
        val l = list()
        val svc = FlowAccessibilityService.instance
        if (svc == null) { finish("Automation stopped", "Accessibility turned off."); return }
        if (index >= l.size) { index = 0; finish("Automation finished", "All prompts were sent."); return }
        svc.pasteAndRun(l[index]) { ok, msg ->
            if (!running) return@pasteAndRun
            if (!ok) { finish("Automation stopped", "Stopped at prompt ${index + 1}: $msg"); return@pasteAndRun }
            index++
            if (index >= l.size) {
                if (flag("loop", false)) index = 0
                else { index = 0; finish("Automation finished", "All prompts were sent."); return@pasteAndRun }
            }
            val base = Prefs.delay(this)
            remaining = if (flag("jitter", false)) (base * (0.8 + Math.random() * 0.4)).toInt().coerceAtLeast(3) else base
            refresh()
            h.postDelayed(tick, 1000)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            if (paused) { h.postDelayed(this, 500); return }
            remaining--
            if (remaining <= 0) { remaining = 0; refresh(); step() }
            else { refresh(); h.postDelayed(this, 1000) }
        }
    }
}
