# Prompt Shots + FLOW floating window (v2.2)

**Build:** upload this project to GitHub, open Actions > Build APK > Run workflow, then download the APK artifact.

## v2.2 changes
- Main screen now shows only **Float** and **Settings**, each with a rotating rainbow edge and glow.
- When Run all finishes (or stops on an error) the floating window only sends a **notification**, no toast.
- **Settings > Notification sound**: Upload a sound, Play to preview, then **Save**. That sound plays when automation finishes. "Use default sound" resets it.

## How to use
1. Open the app, tap the red chips (or **Setup**) and turn on: floating window, accessibility, notifications.
2. Tap **Float**. A round FLOW bubble appears over other apps.
3. Open Google Flow, tap the bubble, paste your prompts (one per line, or separated by blank lines).
4. **Run this** sends one prompt. **Run all** sends them one by one with the wait time from Setup.

## Image / Video / Auto
The panel has three buttons: **Auto**, **Image**, **Video**. Image and Video each keep their own prompt list.
In **Auto**, the app reads the Flow screen (model chip such as Nano Banana / Imagen = image, Veo = video) and switches to the matching list. The panel shows what it detected. Detection is keyword based, so if it guesses wrong, just tap Image or Video.

## Floating panel circles (hold any circle to see what it does)
Row 1: ▶ run this · ⏩ run all / ■ stop · ⏸ pause · ‹ prev · › skip
Row 2: ↺ restart · 📋 paste list · 🗑 clear · ⏱ wait time · 🔁 loop
Row 3: 🎲 random wait · 🌈 rainbow glow on/off · 🙈 auto-hide panel · ! help · ✕ close
Row 4: ⏺ screen record · 👆 show touch
- Recording is 60 fps (falls back to 30 fps if the phone's encoder can't) and video only.
- While recording a small control appears: red **■** box (stop + save to Gallery), **⏸** pause/resume and a timer. Drag it by the timer. The notification has Pause and Stop too.
- Videos go to Movies/PromptShots (Android 10+, shows in Gallery right away).
- **Show touch** draws a circle where you tap. Android only lets an app change this setting after a one-time grant from a computer:
  `adb shell pm grant com.promptshots.flow android.permission.WRITE_SECURE_SETTINGS`
  Without it, turn on *Settings > Developer options > Show taps* by hand.
Orange circle = option is on.

## What's new in 2.1
- Cleaner UI: status chips (tap to fix), progress bar, offline screen with Try again.
- Panel pops in/out with an animation and has a rotating rainbow border. Bubble and border follow the screen refresh rate (60 fps or higher).
- Bubble has a rotating rainbow glow and shows a live countdown (green) while Run all is running; snaps to screen edges.
- Run all **stops** if the prompt box or Generate button can't be found, instead of silently skipping prompts. The failed prompt stays selected.
- Generate detection retries a few times and only matches short, whole-word labels.
- Prompts auto-save as you type; blank-line separated multi-line prompts supported.
- Panel stays on screen; hides itself when Run all starts.
- Notification has a Close action; Float button toggles to Stop float.
